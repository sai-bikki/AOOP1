package dip;

public interface Message {
	 void sendMessage(String message, String receiver);

}
