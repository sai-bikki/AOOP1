package lsp;

public class Human implements Worker , Eater {
	 public void work() {
	        System.out.println("Human is working.");
	    }
	    public void eat() {
	        System.out.println("Human is eating.");
	    }

}
