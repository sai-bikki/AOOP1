package lsp;

public interface Eater {
	void eat();

}
