package lsp;

public interface Worker {
	void work();

}
