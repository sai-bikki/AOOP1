package employee;

public class Employees {
	  private String name;
	    private String role;

	    public Employees(String name, String role) {
	        this.name = name;
	        this.role = role;
	    }

	    public String getName() {
	        return name;
	    }

	    public String getRole() {
	        return role;
	    }
	    public String toString() {
	        return "Employee{" +
	                "name='" + name + '\'' +
	                ", role='" + role + '\'' +
	                '}';
	    }

}
