package LSP;

public class Sparrow extends Bird{
	public void fly() {
        System.out.println("The sparrow is flying.");
    }

}
